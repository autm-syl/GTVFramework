//
//  GTVLib.h
//  GTVLib
//
//  Created by Sylvanas on 6/22/20.
//  Copyright © 2020 Sylvanas. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FirebaseService.h"
#import "GTVManager.h"


//@interface GTVLib : NSObject
//
//@end
